import { useState } from 'react'
import { CATEGORIES } from '../data/recettes'
import type { Recette } from '../data/recettes'
import { BadgeDifficulte } from '../components/communs'
import { IconeFlecheGauche, IconeCoeur, IconeHorloge, IconePortions, IconeFlamme, IconePanier, IconeLecture, IconeCaseCochee } from '../components/icones'

export default function RecetteDetail({
  recette,
  favori,
  onFavori,
  onRetour,
  onAjouterEpicerie,
  onModeCuisine,
}: {
  recette: Recette
  favori: boolean
  onFavori: () => void
  onRetour: () => void
  onAjouterEpicerie: () => void
  onModeCuisine: () => void
}) {
  const [coches, setCoches] = useState<Set<number>>(new Set())
  const [ajoute, setAjoute] = useState(false)
  const total = recette.tempsPrep + recette.tempsCuisson

  const basculerIngredient = (i: number) =>
    setCoches((s) => {
      const n = new Set(s)
      n.has(i) ? n.delete(i) : n.add(i)
      return n
    })

  const infos = [
    { icone: IconeHorloge, label: `${total} min`, sous: 'Temps total' },
    { icone: IconePortions, label: recette.portions, sous: 'Portions' },
    { icone: IconeFlamme, label: `${recette.temperature} °C`, sous: 'Air Fryer' },
  ]

  return (
    <div className="anim-slide-left min-h-full bg-[var(--creme)] pb-32">
      {/* Photo hero */}
      <div className="relative">
        <img src={recette.image} alt={recette.titre} className="w-full h-72 object-cover anim-scale-in" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-[var(--creme)]" style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, transparent 30%, transparent 72%, var(--creme) 100%)' }} />
        <button
          onClick={onRetour}
          aria-label="Retour"
          className="absolute top-5 left-5 w-10 h-10 rounded-full bg-white/90 backdrop-blur flex items-center justify-center text-[var(--encre)] active:scale-90 transition-transform"
          style={{ top: 'calc(1.25rem + env(safe-area-inset-top))' }}
        >
          <IconeFlecheGauche className="w-5 h-5" />
        </button>
        <button
          onClick={onFavori}
          aria-label="Favori"
          className={`absolute right-5 w-10 h-10 rounded-full backdrop-blur flex items-center justify-center active:scale-90 transition-all ${
            favori ? 'bg-[var(--terracotta)] text-white' : 'bg-white/90 text-[var(--encre)]'
          }`}
          style={{ top: 'calc(1.25rem + env(safe-area-inset-top))' }}
        >
          <IconeCoeur plein={favori} className="w-5 h-5" />
        </button>
      </div>

      {/* Titre */}
      <div className="px-5 -mt-10 relative">
        <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-[var(--terracotta)]">
          {CATEGORIES[recette.categorie]}
        </p>
        <h1 className="font-display text-[28px] leading-[1.15] font-semibold text-[var(--encre)] mt-1">
          {recette.titre}
        </h1>
        <p className="text-[14px] text-[var(--encre-douce)] leading-relaxed mt-2">{recette.description}</p>

        {/* Infos rapides */}
        <div className="grid grid-cols-4 gap-2 mt-5">
          {infos.map((info) => (
            <div key={info.sous} className="bg-[var(--carte)] border border-[var(--ligne)] rounded-2xl px-2 py-3 flex flex-col items-center gap-1">
              <info.icone className="w-4 h-4 text-[var(--terracotta)]" />
              <span className="text-[13px] font-bold text-[var(--encre)] text-center leading-tight">{info.label}</span>
              <span className="text-[10px] text-[var(--encre-douce)]">{info.sous}</span>
            </div>
          ))}
          <div className="bg-[var(--carte)] border border-[var(--ligne)] rounded-2xl px-2 py-3 flex flex-col items-center justify-center gap-1">
            <BadgeDifficulte difficulte={recette.difficulte} />
            <span className="text-[10px] text-[var(--encre-douce)]">Niveau</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mt-4">
          {recette.tags.map((t) => (
            <span key={t} className="text-[12px] font-medium px-3 py-1.5 rounded-full bg-[var(--creme-fonce)] text-[var(--encre-douce)]">
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* Ingrédients */}
      <section className="px-5 mt-8">
        <h2 className="font-display text-[20px] font-semibold text-[var(--encre)] mb-1">Ingrédients</h2>
        <p className="text-[13px] text-[var(--encre-douce)] mb-4">Touchez pour cocher ce que vous avez.</p>
        <ul className="bg-[var(--carte)] border border-[var(--ligne)] rounded-[22px] divide-y divide-[var(--ligne)] overflow-hidden">
          {recette.ingredients.map((ing, i) => (
            <li key={i}>
              <button onClick={() => basculerIngredient(i)} className="w-full flex items-center gap-3.5 px-4 py-3.5 text-left active:bg-[var(--creme)]">
                <span
                  className={`w-6 h-6 rounded-full border-2 shrink-0 flex items-center justify-center transition-colors ${
                    coches.has(i) ? 'bg-[var(--vert)] border-[var(--vert)] text-white' : 'border-[var(--ligne)] text-transparent'
                  }`}
                >
                  <IconeCaseCochee className="w-4 h-4" />
                </span>
                <span className={`flex-1 text-[14.5px] leading-snug ${coches.has(i) ? 'text-[var(--encre-douce)] line-through' : 'text-[var(--encre)]'}`}>
                  {ing.nom}
                </span>
                <span className="text-[13px] font-semibold text-[var(--encre-douce)] shrink-0">{ing.quantite}</span>
              </button>
            </li>
          ))}
        </ul>
        <button
          onClick={() => { onAjouterEpicerie(); setAjoute(true); setTimeout(() => setAjoute(false), 2200) }}
          className={`mt-4 w-full py-4 rounded-full font-semibold text-[15px] flex items-center justify-center gap-2 active:scale-[0.98] transition-all border-2 ${
            ajoute
              ? 'bg-[var(--vert)] border-[var(--vert)] text-white'
              : 'border-[var(--encre)] text-[var(--encre)] bg-transparent'
          }`}
        >
          {ajoute ? (
            <><IconeCaseCochee className="w-5 h-5" /> Ajouté à votre liste&nbsp;!</>
          ) : (
            <><IconePanier className="w-5 h-5" /> Ajouter les ingrédients à ma liste d’épicerie</>
          )}
        </button>
      </section>

      {/* Préparation */}
      <section className="px-5 mt-9">
        <h2 className="font-display text-[20px] font-semibold text-[var(--encre)] mb-4">Préparation</h2>
        <ol className="space-y-3">
          {recette.etapes.map((etape, i) => (
            <li key={i} className="flex gap-4 bg-[var(--carte)] border border-[var(--ligne)] rounded-[20px] p-4">
              <span className="font-display text-[26px] font-semibold text-[var(--moutarde)] leading-none pt-0.5 w-9 shrink-0">
                {String(i + 1).padStart(2, '0')}
              </span>
              <div>
                <h3 className="font-semibold text-[15px] text-[var(--encre)]">{etape.titre}</h3>
                <p className="text-[14px] text-[var(--encre-douce)] leading-relaxed mt-1">{etape.texte}</p>
                {etape.duree && (
                  <span className="inline-flex items-center gap-1.5 mt-2 text-[12px] font-semibold text-[var(--terracotta)] bg-[var(--terracotta-pale)] px-2.5 py-1 rounded-full">
                    <IconeHorloge className="w-3.5 h-3.5" /> {etape.duree} min
                  </span>
                )}
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* Bouton mode cuisine */}
      <div className="fixed bottom-0 left-0 right-0 z-40 px-5 pb-5 pt-3 bg-gradient-to-t from-[var(--creme)] via-[var(--creme)]/95 to-transparent" style={{ paddingBottom: 'calc(1.25rem + env(safe-area-inset-bottom))' }}>
        <div className="max-w-md mx-auto">
          <button
            onClick={onModeCuisine}
            className="w-full py-4 rounded-full bg-[var(--terracotta)] text-white font-semibold text-[16px] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
            style={{ boxShadow: '0 8px 24px rgba(213,89,63,0.35)' }}
          >
            <IconeLecture className="w-4 h-4" /> Commencer la recette
          </button>
        </div>
      </div>
    </div>
  )
}
