import { useMemo, useState } from 'react'
import type { ArticleEpicerie } from '../lib/store'
import { EtatVide } from '../components/communs'
import { IconePanier, IconePlus, IconeCaseCochee, IconePoubelle } from '../components/icones'

export default function Epicerie({
  articles,
  basculer,
  supprimer,
  ajouterManuel,
  viderCoches,
  allerRecherche,
}: {
  articles: ArticleEpicerie[]
  basculer: (id: string) => void
  supprimer: (id: string) => void
  ajouterManuel: (nom: string) => void
  viderCoches: () => void
  allerRecherche: () => void
}) {
  const [saisie, setSaisie] = useState('')

  const groupes = useMemo(() => {
    const map = new Map<string, ArticleEpicerie[]>()
    for (const a of articles) {
      const g = a.groupe || 'Autres'
      if (!map.has(g)) map.set(g, [])
      map.get(g)!.push(a)
    }
    return [...map.entries()]
  }, [articles])

  const nbCoches = articles.filter((a) => a.coche).length

  const soumettre = () => {
    ajouterManuel(saisie)
    setSaisie('')
  }

  return (
    <div className="pb-28 px-5 pt-6" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
      <div className="flex items-baseline justify-between">
        <h1 className="font-display text-[26px] font-semibold text-[var(--encre)]">Ma liste d’épicerie</h1>
        {nbCoches > 0 && (
          <button onClick={viderCoches} className="text-[13px] font-semibold text-[var(--terracotta)]">
            Retirer les cochés ({nbCoches})
          </button>
        )}
      </div>
      <p className="text-[14px] text-[var(--encre-douce)] mt-1.5 mb-5">
        Les ingrédients de vos recettes s’ajoutent ici automatiquement.
      </p>

      {/* Ajout manuel */}
      <div className="flex items-center gap-2 bg-[var(--carte)] border border-[var(--ligne)] rounded-full pl-5 pr-2 py-2 mb-6" style={{ boxShadow: '0 2px 12px rgba(46,38,32,0.05)' }}>
        <input
          value={saisie}
          onChange={(e) => setSaisie(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && soumettre()}
          placeholder="Ajouter un article…"
          className="flex-1 bg-transparent outline-none text-[15px] text-[var(--encre)] placeholder:text-[var(--encre-douce)]"
        />
        <button
          onClick={soumettre}
          aria-label="Ajouter"
          className="w-10 h-10 rounded-full bg-[var(--terracotta)] text-white flex items-center justify-center active:scale-90 transition-transform"
        >
          <IconePlus className="w-5 h-5" />
        </button>
      </div>

      {articles.length === 0 ? (
        <EtatVide
          icone={<IconePanier className="w-7 h-7" />}
          titre="Votre liste est vide"
          texte="Ajoutez les ingrédients d’une recette ou saisissez un article manuellement."
          action="Trouver une recette"
          onAction={allerRecherche}
        />
      ) : (
        <div className="space-y-6 decalle">
          {groupes.map(([groupe, items]) => (
            <section key={groupe} className="anim-fade-up">
              <h2 className="text-[12px] font-bold uppercase tracking-[0.1em] text-[var(--terracotta)] mb-2.5">{groupe}</h2>
              <ul className="bg-[var(--carte)] border border-[var(--ligne)] rounded-[20px] divide-y divide-[var(--ligne)] overflow-hidden">
                {items.map((a) => (
                  <li key={a.id} className="flex items-center gap-3 px-4 py-3">
                    <button onClick={() => basculer(a.id)} className="flex items-center gap-3 flex-1 text-left min-w-0">
                      <span
                        className={`w-6 h-6 rounded-full border-2 shrink-0 flex items-center justify-center transition-colors ${
                          a.coche ? 'bg-[var(--vert)] border-[var(--vert)] text-white' : 'border-[var(--ligne)] text-transparent'
                        }`}
                      >
                        <IconeCaseCochee className="w-4 h-4" />
                      </span>
                      <span className="min-w-0">
                        <span className={`block text-[14.5px] leading-snug truncate ${a.coche ? 'line-through text-[var(--encre-douce)]' : 'text-[var(--encre)]'}`}>
                          {a.nom}
                        </span>
                        <span className="block text-[12px] text-[var(--encre-douce)]">
                          {[a.quantite, a.recetteTitre].filter(Boolean).join(' · ')}
                        </span>
                      </span>
                    </button>
                    <button onClick={() => supprimer(a.id)} aria-label="Supprimer" className="text-[var(--encre-douce)] active:text-[var(--terracotta)] p-1">
                      <IconePoubelle className="w-[18px] h-[18px]" />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  )
}
