import { useMemo, useState } from 'react'
import { RECETTES, CATEGORIES, INGREDIENTS_POPULAIRES } from '../data/recettes'
import type { Categorie, Recette } from '../data/recettes'
import { CarteRecette, Chip, EtatVide } from '../components/communs'
import { IconeLoupe, IconeCroix, IconePanierIngredients, IconeCaseCochee } from '../components/icones'

export interface PresetRecherche {
  tag?: string
  tempsMax?: number
  ingredients?: boolean
  favoris?: boolean
}

const FILTRES_TEMPS = [
  { id: 10, label: 'Moins de 10 min' },
  { id: 20, label: '10–20 min' },
  { id: 30, label: '20–30 min' },
  { id: 999, label: '30 min +' },
]
const DIFFICULTES = ['Facile', 'Intermédiaire', 'Avancé']

function totalMin(r: Recette) {
  return r.tempsPrep + r.tempsCuisson
}

export default function Recherche({
  preset,
  favoris,
  basculerFavori,
  ouvrirRecette,
}: {
  preset: PresetRecherche | null
  favoris: string[]
  basculerFavori: (id: string) => void
  ouvrirRecette: (id: string) => void
}) {
  const [texte, setTexte] = useState('')
  const [tag, setTag] = useState<string | null>(preset?.tag ?? null)
  const [temps, setTemps] = useState<number | null>(preset?.tempsMax ?? null)
  const [difficulte, setDifficulte] = useState<string | null>(null)
  const [categorie, setCategorie] = useState<Categorie | null>(null)
  const [modeIngredients, setModeIngredients] = useState(preset?.ingredients ?? false)
  const [mesIngredients, setMesIngredients] = useState<string[]>([])

  const resultats = useMemo(() => {
    let liste = RECETTES
    if (texte.trim()) {
      const q = texte.trim().toLowerCase()
      liste = liste.filter(
        (r) =>
          r.titre.toLowerCase().includes(q) ||
          r.description.toLowerCase().includes(q) ||
          r.ingredients.some((i) => i.nom.toLowerCase().includes(q)) ||
          r.tags.some((t) => t.toLowerCase().includes(q))
      )
    }
    if (tag) liste = liste.filter((r) => r.tags.includes(tag))
    if (temps !== null) {
      if (temps === 999) liste = liste.filter((r) => totalMin(r) > 30)
      else if (temps === 10) liste = liste.filter((r) => totalMin(r) < 10)
      else if (temps === 20) liste = liste.filter((r) => totalMin(r) >= 10 && totalMin(r) <= 20)
      else liste = liste.filter((r) => totalMin(r) > 20 && totalMin(r) <= 30)
    }
    if (difficulte) liste = liste.filter((r) => r.difficulte === difficulte)
    if (categorie) liste = liste.filter((r) => r.categorie === categorie)
    if (modeIngredients && mesIngredients.length > 0) {
      liste = liste
        .map((r) => ({ r, nb: r.ingredientsCles.filter((c) => mesIngredients.includes(c)).length }))
        .filter((x) => x.nb > 0)
        .sort((a, b) => b.nb - a.nb)
        .map((x) => x.r)
    }
    return liste
  }, [texte, tag, temps, difficulte, categorie, modeIngredients, mesIngredients])

  const nbFiltres = [tag, temps !== null ? 'x' : null, difficulte, categorie].filter(Boolean).length

  const basculerIngredient = (cle: string) =>
    setMesIngredients((m) => (m.includes(cle) ? m.filter((c) => c !== cle) : [...m, cle]))

  return (
    <div className="pb-28">
      <header className="px-5 pt-6 sticky top-0 z-30 bg-[var(--creme)]/95 backdrop-blur-md pb-4" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
        <h1 className="font-display text-[26px] font-semibold text-[var(--encre)]">Recherche</h1>
        <div className="mt-4 flex items-center gap-3 bg-[var(--carte)] border border-[var(--ligne)] rounded-full px-5 py-3.5" style={{ boxShadow: '0 2px 12px rgba(46,38,32,0.05)' }}>
          <IconeLoupe className="w-5 h-5 text-[var(--encre-douce)] shrink-0" />
          <input
            value={texte}
            onChange={(e) => setTexte(e.target.value)}
            placeholder="Recette, ingrédient, tag…"
            className="flex-1 bg-transparent outline-none text-[15px] text-[var(--encre)] placeholder:text-[var(--encre-douce)]"
          />
          {texte && (
            <button onClick={() => setTexte('')} aria-label="Effacer">
              <IconeCroix className="w-4 h-4 text-[var(--encre-douce)]" />
            </button>
          )}
        </div>
      </header>

      {/* Mode ingrédients */}
      <section className="px-5 mt-2">
        <button
          onClick={() => setModeIngredients(!modeIngredients)}
          className={`w-full flex items-center justify-between px-5 py-4 rounded-[20px] border transition-all active:scale-[0.99] ${
            modeIngredients ? 'bg-[var(--vert-pale)] border-[var(--vert)]' : 'bg-[var(--carte)] border-[var(--ligne)]'
          }`}
        >
          <span className="flex items-center gap-3">
            <IconePanierIngredients className="w-5 h-5 text-[var(--vert)]" />
            <span className="font-semibold text-[15px] text-[var(--encre)]">J’ai ces ingrédients</span>
          </span>
          <span className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
            modeIngredients ? 'bg-[var(--vert)] border-[var(--vert)] text-white' : 'border-[var(--ligne)] text-transparent'
          }`}>
            <IconeCaseCochee className="w-4 h-4" />
          </span>
        </button>

        {modeIngredients && (
          <div className="anim-fade-up mt-4">
            <p className="text-[13px] text-[var(--encre-douce)] mb-3">
              Sélectionnez ce que vous avez sous la main&nbsp;:
            </p>
            <div className="flex flex-wrap gap-2">
              {INGREDIENTS_POPULAIRES.map((ing) => (
                <Chip
                  key={ing.cle}
                  label={ing.label}
                  actif={mesIngredients.includes(ing.cle)}
                  onClick={() => basculerIngredient(ing.cle)}
                />
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Filtres */}
      <section className="mt-5 space-y-3">
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5">
          <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--encre-douce)] self-center shrink-0 w-14">Temps</span>
          {FILTRES_TEMPS.map((f) => (
            <Chip key={f.id} label={f.label} actif={temps === f.id} onClick={() => setTemps(temps === f.id ? null : f.id)} />
          ))}
        </div>
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5">
          <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--encre-douce)] self-center shrink-0 w-14">Niveau</span>
          {DIFFICULTES.map((d) => (
            <Chip key={d} label={d} actif={difficulte === d} onClick={() => setDifficulte(difficulte === d ? null : d)} />
          ))}
        </div>
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5">
          <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--encre-douce)] self-center shrink-0 w-14">Type</span>
          {(Object.keys(CATEGORIES) as Categorie[]).map((c) => (
            <Chip key={c} label={CATEGORIES[c]} actif={categorie === c} onClick={() => setCategorie(categorie === c ? null : c)} />
          ))}
        </div>
      </section>

      {/* Résultats */}
      <section className="px-5 mt-6">
        <div className="flex items-baseline justify-between mb-4">
          <p className="text-[14px] text-[var(--encre-douce)]">
            <strong className="text-[var(--encre)]">{resultats.length}</strong> recette{resultats.length > 1 ? 's' : ''}
            {modeIngredients && mesIngredients.length > 0 && ' compatibles'}
            {nbFiltres > 0 && ` · ${nbFiltres} filtre${nbFiltres > 1 ? 's' : ''}`}
          </p>
          {(nbFiltres > 0 || tag) && (
            <button
              onClick={() => { setTag(null); setTemps(null); setDifficulte(null); setCategorie(null) }}
              className="text-[13px] font-semibold text-[var(--terracotta)]"
            >
              Réinitialiser
            </button>
          )}
        </div>

        {resultats.length === 0 ? (
          <EtatVide
            icone={<IconeLoupe className="w-7 h-7" />}
            titre="Aucune recette trouvée"
            texte="Essayez d’autres mots-clés ou retirez quelques filtres."
          />
        ) : (
          <div className="grid grid-cols-2 gap-4 decalle">
            {resultats.map((r) => (
              <div key={r.id} className="relative">
                <CarteRecette
                  recette={r}
                  favori={favoris.includes(r.id)}
                  onFavori={() => basculerFavori(r.id)}
                  onOuvrir={() => ouvrirRecette(r.id)}
                />
                {modeIngredients && mesIngredients.length > 0 && (
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-[var(--vert)] text-white text-[11px] font-bold backdrop-blur-sm">
                    Vous avez {r.ingredientsCles.filter((c) => mesIngredients.includes(c)).length}{'\u00a0'}sur{'\u00a0'}{r.ingredientsCles.length}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
