import { RECETTES } from '../data/recettes'
import { CarteRecette, EtatVide } from '../components/communs'
import { IconeCoeur } from '../components/icones'

export default function Favoris({
  favoris,
  basculerFavori,
  ouvrirRecette,
  allerRecherche,
}: {
  favoris: string[]
  basculerFavori: (id: string) => void
  ouvrirRecette: (id: string) => void
  allerRecherche: () => void
}) {
  const liste = RECETTES.filter((r) => favoris.includes(r.id))

  return (
    <div className="pb-28 px-5 pt-6" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
      <h1 className="font-display text-[26px] font-semibold text-[var(--encre)]">Mes favoris</h1>
      <p className="text-[14px] text-[var(--encre-douce)] mt-1.5 mb-6">
        {liste.length > 0
          ? `${liste.length} recette${liste.length > 1 ? 's' : ''} sauvegardée${liste.length > 1 ? 's' : ''}`
          : 'Vos recettes préférées, réunies ici.'}
      </p>

      {liste.length === 0 ? (
        <EtatVide
          icone={<IconeCoeur className="w-7 h-7" />}
          titre="Aucune recette sauvegardée"
          texte="Trouvez une recette qui vous plaît et ajoutez-la à vos favoris."
          action="Explorer les recettes"
          onAction={allerRecherche}
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 decalle">
          {liste.map((r) => (
            <CarteRecette
              key={r.id}
              recette={r}
              favori
              onFavori={() => basculerFavori(r.id)}
              onOuvrir={() => ouvrirRecette(r.id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
