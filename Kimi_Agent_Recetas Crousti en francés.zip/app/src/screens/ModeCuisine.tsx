import { useEffect, useRef, useState } from 'react'
import type { Recette } from '../data/recettes'
import { IconeCroix, IconeFlecheGauche, IconeFlecheDroite, IconeMinuteur, IconeLecture, IconePause, IconeCaseCochee } from '../components/icones'

function bip() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
    ;[0, 0.35, 0.7].forEach((t) => {
      const o = ctx.createOscillator()
      const g = ctx.createGain()
      o.connect(g); g.connect(ctx.destination)
      o.frequency.value = 880
      g.gain.setValueAtTime(0.25, ctx.currentTime + t)
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3)
      o.start(ctx.currentTime + t)
      o.stop(ctx.currentTime + t + 0.3)
    })
  } catch { /* audio indisponible */ }
}

function Minuteur({ minutes }: { minutes: number }) {
  const [reste, setReste] = useState(minutes * 60)
  const [actif, setActif] = useState(false)
  const [termine, setTermine] = useState(false)
  const ref = useRef<number | null>(null)

  useEffect(() => {
    if (actif && reste > 0) {
      ref.current = window.setInterval(() => setReste((r) => r - 1), 1000)
    }
    return () => { if (ref.current) clearInterval(ref.current) }
  }, [actif])

  useEffect(() => {
    if (reste === 0 && actif) {
      setActif(false)
      setTermine(true)
      bip()
    }
  }, [reste, actif])

  const m = Math.floor(reste / 60)
  const s = reste % 60
  const progression = 1 - reste / (minutes * 60)

  return (
    <div className="mt-6 rounded-[22px] bg-[var(--encre)] text-[var(--creme)] p-5 anim-pop">
      <div className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.1em] text-[var(--moutarde)]">
        <IconeMinuteur className="w-4 h-4" /> Minuteur
      </div>
      <div className="chiffres-minuteur text-[52px] font-semibold text-center my-3 leading-none">
        {String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}
      </div>
      <div className="h-1.5 rounded-full bg-white/15 overflow-hidden mb-4">
        <div
          className="h-full rounded-full transition-all duration-1000"
          style={{ width: `${progression * 100}%`, background: termine ? 'var(--vert)' : 'var(--moutarde)' }}
        />
      </div>
      <p className="text-center text-[13px] text-white/60 mb-4">
        {termine ? 'Temps écoulé — vérifiez la cuisson !' : actif ? 'Cuisson en cours' : 'Prêt à démarrer'}
      </p>
      <div className="flex gap-2">
        {!termine ? (
          <button
            onClick={() => setActif(!actif)}
            className="flex-1 py-3 rounded-full bg-[var(--moutarde)] text-[var(--encre)] font-bold text-[14px] flex items-center justify-center gap-2 active:scale-95 transition-transform"
          >
            {actif ? <><IconePause className="w-4 h-4" /> Pause</> : <><IconeLecture className="w-4 h-4" /> {reste < minutes * 60 ? 'Reprendre' : 'Démarrer le minuteur'}</>}
          </button>
        ) : (
          <button
            onClick={() => { setReste(minutes * 60); setTermine(false) }}
            className="flex-1 py-3 rounded-full bg-[var(--vert)] text-white font-bold text-[14px] active:scale-95 transition-transform"
          >
            Recommencer
          </button>
        )}
        {(reste < minutes * 60 || termine) && !termine && (
          <button
            onClick={() => { setActif(false); setReste(minutes * 60) }}
            className="px-5 py-3 rounded-full bg-white/10 text-white/80 font-semibold text-[14px] active:scale-95 transition-transform"
          >
            Remettre
          </button>
        )}
      </div>
    </div>
  )
}

export default function ModeCuisine({ recette, onQuitter }: { recette: Recette; onQuitter: () => void }) {
  const [etape, setEtape] = useState(0)
  const [termine, setTermine] = useState(false)
  const courante = recette.etapes[etape]
  const derniere = etape === recette.etapes.length - 1

  return (
    <div className="fixed inset-0 z-50 bg-[var(--creme)] flex flex-col anim-pop">
      {/* En-tête */}
      <header className="px-5 pt-5 flex items-center justify-between" style={{ paddingTop: 'calc(1.25rem + env(safe-area-inset-top))' }}>
        <button
          onClick={onQuitter}
          aria-label="Quitter le mode cuisine"
          className="w-10 h-10 rounded-full bg-[var(--carte)] border border-[var(--ligne)] flex items-center justify-center text-[var(--encre)] active:scale-90 transition-transform"
        >
          <IconeCroix className="w-5 h-5" />
        </button>
        <div className="text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-[var(--terracotta)]">Mode cuisine</p>
          <p className="text-[13px] font-semibold text-[var(--encre)] max-w-[200px] truncate">{recette.titre}</p>
        </div>
        <span className="text-[13px] font-bold text-[var(--encre-douce)] w-10 text-right">
          {etape + 1}/{recette.etapes.length}
        </span>
      </header>

      {/* Progression */}
      <div className="px-5 mt-4">
        <div className="h-1.5 rounded-full bg-[var(--creme-fonce)] overflow-hidden">
          <div
            className="h-full rounded-full bg-[var(--terracotta)] transition-all duration-500"
            style={{ width: `${((etape + 1) / recette.etapes.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Étape */}
      {!termine ? (
        <main key={etape} className="flex-1 flex flex-col px-6 pt-10 overflow-y-auto">
          <span className="anim-fade-up font-display text-[15px] font-semibold text-[var(--moutarde)] uppercase tracking-[0.15em]">
            Étape {String(etape + 1).padStart(2, '0')}
          </span>
          <h2 className="anim-fade-up font-display text-[34px] font-semibold text-[var(--encre)] leading-tight mt-2" style={{ animationDelay: '0.05s' }}>
            {courante.titre}
          </h2>
          <p className="anim-fade-up text-[18px] leading-relaxed text-[var(--encre)] opacity-80 mt-5" style={{ animationDelay: '0.1s' }}>
            {courante.texte}
          </p>
          {courante.duree && <Minuteur key={`m-${etape}`} minutes={courante.duree} />}
        </main>
      ) : (
        <main className="flex-1 flex flex-col items-center justify-center px-8 text-center">
          <div className="anim-pop w-20 h-20 rounded-full bg-[var(--vert-pale)] flex items-center justify-center text-[var(--vert)] mb-6">
            <IconeCaseCochee className="w-9 h-9" />
          </div>
          <h2 className="anim-fade-up font-display text-[30px] font-semibold text-[var(--encre)]">Bon appétit&nbsp;!</h2>
          <p className="anim-fade-up text-[15px] text-[var(--encre-douce)] mt-3 leading-relaxed" style={{ animationDelay: '0.08s' }}>
            Votre recette «&nbsp;{recette.titre}&nbsp;» est terminée. Régalez-vous&nbsp;!
          </p>
        </main>
      )}

      {/* Navigation */}
      <footer className="px-5 pb-6 pt-3 flex gap-3" style={{ paddingBottom: 'calc(1.5rem + env(safe-area-inset-bottom))' }}>
        {!termine ? (
          <>
            <button
              onClick={() => setEtape(Math.max(0, etape - 1))}
              disabled={etape === 0}
              className="flex-1 py-4 rounded-full border-2 border-[var(--ligne)] bg-[var(--carte)] font-semibold text-[15px] text-[var(--encre)] flex items-center justify-center gap-1.5 disabled:opacity-40 active:scale-[0.98] transition-all"
            >
              <IconeFlecheGauche className="w-4 h-4" /> Précédent
            </button>
            <button
              onClick={() => (derniere ? setTermine(true) : setEtape(etape + 1))}
              className="flex-[1.4] py-4 rounded-full bg-[var(--terracotta)] text-white font-semibold text-[15px] flex items-center justify-center gap-1.5 active:scale-[0.98] transition-transform"
            >
              {derniere ? 'Terminer la recette' : <>Étape suivante <IconeFlecheDroite className="w-4 h-4" /></>}
            </button>
          </>
        ) : (
          <button
            onClick={onQuitter}
            className="flex-1 py-4 rounded-full bg-[var(--encre)] text-[var(--creme)] font-semibold text-[15px] active:scale-[0.98] transition-transform"
          >
            Retour à la recette
          </button>
        )}
      </footer>
    </div>
  )
}
