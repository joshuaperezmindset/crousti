import { useState } from 'react'
import { LogoCrousti, IconeFlecheDroite } from '../components/icones'

const SLIDES = [
  {
    titre: 'Votre Air Fryer.\nDe meilleures idées.',
    texte: '50 recettes végétariennes croustillantes, pensées pour votre friteuse à air.',
    accent: 'var(--terracotta)',
    fond: 'var(--terracotta-pale)',
    symbole: (
      <svg viewBox="0 0 120 120" className="w-36 h-36" fill="none">
        <rect x="20" y="14" width="80" height="92" rx="18" fill="#d5593f" />
        <rect x="32" y="26" width="56" height="44" rx="10" fill="#fcf8ef" />
        <path d="M40 62c4-14 12-22 20-22s16 8 20 22" stroke="#dfa43d" strokeWidth="4" strokeLinecap="round" />
        <circle cx="40" cy="86" r="4" fill="#fcf8ef" /><circle cx="52" cy="86" r="4" fill="#dfa43d" />
        <rect x="64" y="80" width="20" height="10" rx="5" fill="#fcf8ef" />
      </svg>
    ),
  },
  {
    titre: 'Des recettes simples\net rapides.',
    texte: 'Des étapes claires, un mode cuisine guidé et un minuteur intégré. Posez votre téléphone et cuisinez.',
    accent: 'var(--vert)',
    fond: 'var(--vert-pale)',
    symbole: (
      <svg viewBox="0 0 120 120" className="w-36 h-36" fill="none">
        <circle cx="60" cy="60" r="44" fill="#16ac7a" />
        <circle cx="60" cy="60" r="32" fill="#fcf8ef" />
        <path d="M60 42v18l12 8" stroke="#16ac7a" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    titre: 'Cuisinez avec ce que\nvous avez déjà.',
    texte: 'Sélectionnez vos ingrédients et trouvez instantanément les recettes compatibles.',
    accent: 'var(--moutarde)',
    fond: 'var(--moutarde-pale)',
    symbole: (
      <svg viewBox="0 0 120 120" className="w-36 h-36" fill="none">
        <path d="M22 50h76l-8 52a8 8 0 0 1-8 6H38a8 8 0 0 1-8-6l-8-52Z" fill="#dfa43d" />
        <path d="M40 50V34a20 20 0 0 1 40 0v16" stroke="#d5593f" strokeWidth="5" strokeLinecap="round" />
        <circle cx="48" cy="72" r="5" fill="#fcf8ef" /><circle cx="72" cy="72" r="5" fill="#fcf8ef" />
        <path d="M48 88h24" stroke="#fcf8ef" strokeWidth="5" strokeLinecap="round" />
      </svg>
    ),
  },
]

export default function Onboarding({ onTerminer }: { onTerminer: () => void }) {
  const [index, setIndex] = useState(0)
  const slide = SLIDES[index]
  const dernier = index === SLIDES.length - 1

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ background: slide.fond, transition: 'background 0.5s' }}>
      <div className="flex items-center justify-between px-6 pt-6" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
        <div className="flex items-center gap-2">
          <LogoCrousti className="w-7 h-7" />
          <span className="font-display font-semibold text-lg text-[var(--encre)]">Crousti</span>
        </div>
        {!dernier && (
          <button onClick={onTerminer} className="text-[14px] font-medium text-[var(--encre-douce)] px-3 py-2">
            Passer
          </button>
        )}
      </div>

      <div key={index} className="flex-1 flex flex-col items-center justify-center px-10 text-center">
        <div className="anim-pop mb-10">{slide.symbole}</div>
        <h1 className="anim-fade-up font-display text-[34px] leading-[1.12] font-semibold text-[var(--encre)] whitespace-pre-line">
          {slide.titre}
        </h1>
        <p className="anim-fade-up mt-4 text-[16px] leading-relaxed text-[var(--encre-douce)] max-w-[300px]" style={{ animationDelay: '0.1s' }}>
          {slide.texte}
        </p>
      </div>

      <div className="px-6 pb-8" style={{ paddingBottom: 'calc(2rem + env(safe-area-inset-bottom))' }}>
        <div className="flex items-center justify-center gap-2 mb-6">
          {SLIDES.map((_, i) => (
            <span
              key={i}
              className="h-2 rounded-full transition-all duration-300"
              style={{ width: i === index ? 22 : 8, background: i === index ? slide.accent : 'rgba(46,38,32,0.15)' }}
            />
          ))}
        </div>
        <button
          onClick={() => (dernier ? onTerminer() : setIndex(index + 1))}
          className="w-full py-4 rounded-full text-white font-semibold text-[16px] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
          style={{ background: slide.accent }}
        >
          {dernier ? 'Commencer' : 'Suivant'}
          <IconeFlecheDroite className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
