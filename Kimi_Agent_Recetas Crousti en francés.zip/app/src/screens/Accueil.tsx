import { RECETTES } from '../data/recettes'
import { CarteRecette } from '../components/communs'
import { IconeLoupe, IconeEclair, IconeFeuille, IconePanierIngredients, IconeHorloge, IconeCoeur, IconeDe, IconeFlecheDroite, LogoCrousti, IconeFlamme } from '../components/icones'

const RACCOURCIS = [
  { id: 'rapide', label: 'Rapide', icone: IconeEclair, filtre: { type: 'tag' as const, valeur: 'Rapide' } },
  { id: 'vegetalien', label: 'Végétalien', icone: IconeFeuille, filtre: { type: 'tag' as const, valeur: 'Végétalien' } },
  { id: 'ingredients', label: 'Avec mes ingrédients', icone: IconePanierIngredients, filtre: { type: 'ingredients' as const, valeur: '' } },
  { id: 'moins20', label: 'Moins de 20 min', icone: IconeHorloge, filtre: { type: 'temps' as const, valeur: '20' } },
  { id: 'favoris', label: 'Mes favoris', icone: IconeCoeur, filtre: { type: 'favoris' as const, valeur: '' } },
]

export interface NavigationAccueil {
  ouvrirRecette: (id: string) => void
  allerRecherche: (preset?: { tag?: string; tempsMax?: number; ingredients?: boolean; favoris?: boolean }) => void
  allerFavoris: () => void
}

export default function Accueil({
  favoris,
  basculerFavori,
  nav,
}: {
  favoris: string[]
  basculerFavori: (id: string) => void
  nav: NavigationAccueil
}) {
  const populaires = [...RECETTES].sort((a, b) => (a.tempsPrep + a.tempsCuisson) - (b.tempsPrep + b.tempsCuisson)).slice(0, 8)
  const nouveautes = RECETTES.filter((r) => ['falafels-croustillants', 'chou-fleur-buffalo', 'raviolis-croustillants', 'mais-de-rue-grec'].includes(r.id))
  const coupDeCoeur = RECETTES.find((r) => r.id === 'tofu-croustillant')!

  const surprise = () => {
    const r = RECETTES[Math.floor(Math.random() * RECETTES.length)]
    nav.ouvrirRecette(r.id)
  }

  const clicRaccourci = (f: (typeof RACCOURCIS)[number]['filtre']) => {
    if (f.type === 'favoris') return nav.allerFavoris()
    if (f.type === 'ingredients') return nav.allerRecherche({ ingredients: true })
    if (f.type === 'tag') return nav.allerRecherche({ tag: f.valeur })
    if (f.type === 'temps') return nav.allerRecherche({ tempsMax: 20 })
  }

  return (
    <div className="pb-28">
      {/* En-tête */}
      <header className="px-5 pt-6" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <LogoCrousti className="w-9 h-9" />
            <span className="font-display text-[22px] font-semibold tracking-tight text-[var(--encre)]">Crousti</span>
          </div>
          <span className="text-[12px] font-semibold px-3 py-1.5 rounded-full bg-[var(--vert-pale)] text-[#0d7a57]">
            100 % végétarien
          </span>
        </div>
        <h1 className="anim-fade-up font-display text-[30px] leading-[1.15] font-semibold text-[var(--encre)] mt-6">
          Qu’est-ce qu’on cuisine aujourd’hui&nbsp;?
        </h1>

        {/* Barre de recherche */}
        <button
          onClick={() => nav.allerRecherche()}
          className="anim-fade-up mt-5 w-full flex items-center gap-3 bg-[var(--carte)] border border-[var(--ligne)] rounded-full px-5 py-4 text-left active:scale-[0.99] transition-transform"
          style={{ animationDelay: '0.05s', boxShadow: '0 2px 12px rgba(46,38,32,0.05)' }}
        >
          <IconeLoupe className="w-5 h-5 text-[var(--encre-douce)]" />
          <span className="text-[15px] text-[var(--encre-douce)]">Rechercher une recette ou un ingrédient</span>
        </button>
      </header>

      {/* Raccourcis */}
      <div className="no-scrollbar flex gap-2.5 overflow-x-auto px-5 mt-5 anim-fade-up" style={{ animationDelay: '0.1s' }}>
        {RACCOURCIS.map((r) => (
          <button
            key={r.id}
            onClick={() => clicRaccourci(r.filtre)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[var(--carte)] border border-[var(--ligne)] text-[14px] font-medium text-[var(--encre)] whitespace-nowrap active:scale-95 transition-transform"
          >
            <r.icone className="w-4.5 h-4.5 w-[18px] h-[18px] text-[var(--terracotta)]" />
            {r.label}
          </button>
        ))}
      </div>

      {/* Coup de cœur */}
      <section className="px-5 mt-8">
        <article
          onClick={() => nav.ouvrirRecette(coupDeCoeur.id)}
          className="anim-fade-up relative rounded-[26px] overflow-hidden cursor-pointer active:scale-[0.98] transition-transform"
          style={{ animationDelay: '0.15s', boxShadow: '0 8px 28px rgba(46,38,32,0.14)' }}
        >
          <img src={coupDeCoeur.image} alt={coupDeCoeur.titre} className="w-full h-56 object-cover anim-scale-in" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <p className="inline-block text-[11px] font-bold uppercase tracking-[0.12em] text-[var(--encre)] bg-[var(--moutarde)] px-2.5 py-1 rounded-full mb-2">Coup de cœur</p>
            <h2 className="font-display text-[22px] font-semibold text-white leading-tight">{coupDeCoeur.titre}</h2>
            <div className="flex items-center gap-3 mt-2 text-white/85 text-[13px]">
              <span className="flex items-center gap-1"><IconeHorloge className="w-3.5 h-3.5" /> {coupDeCoeur.tempsPrep + coupDeCoeur.tempsCuisson} min</span>
              <span className="flex items-center gap-1"><IconeFlamme className="w-3.5 h-3.5" /> {coupDeCoeur.temperature} °C</span>
            </div>
          </div>
        </article>
      </section>

      {/* Populaires */}
      <section className="mt-9">
        <div className="flex items-baseline justify-between px-5 mb-4">
          <h2 className="font-display text-[21px] font-semibold text-[var(--encre)]">Recettes populaires</h2>
          <button onClick={() => nav.allerRecherche()} className="text-[13px] font-semibold text-[var(--terracotta)] flex items-center gap-0.5">
            Tout voir <IconeFlecheDroite className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="no-scrollbar flex gap-4 overflow-x-auto px-5 decalle">
          {populaires.map((r) => (
            <CarteRecette
              key={r.id}
              recette={r}
              grande
              favori={favoris.includes(r.id)}
              onFavori={() => basculerFavori(r.id)}
              onOuvrir={() => nav.ouvrirRecette(r.id)}
            />
          ))}
        </div>
      </section>

      {/* Besoin d'une idée */}
      <section className="px-5 mt-9">
        <div className="anim-fade-up rounded-[26px] bg-[var(--encre)] text-[var(--creme)] p-6 relative overflow-hidden">
          <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-[var(--terracotta)] opacity-30" />
          <div className="absolute -right-2 bottom-0 w-20 h-20 rounded-full bg-[var(--moutarde)] opacity-25" />
          <h2 className="font-display text-[21px] font-semibold relative">Besoin d’une idée&nbsp;?</h2>
          <p className="text-[14px] text-[var(--creme)] opacity-70 mt-1.5 relative">
            Laissez le hasard choisir votre prochaine recette.
          </p>
          <button
            onClick={surprise}
            className="relative mt-5 flex items-center gap-2 px-6 py-3.5 rounded-full bg-[var(--terracotta)] text-white font-semibold text-[15px] active:scale-95 transition-transform"
          >
            <IconeDe className="w-5 h-5" />
            Trouver une recette pour moi
          </button>
        </div>
      </section>

      {/* Incontournables */}
      <section className="px-5 mt-9">
        <h2 className="font-display text-[21px] font-semibold text-[var(--encre)] mb-4">Les incontournables</h2>
        <div className="grid grid-cols-2 gap-4 decalle">
          {nouveautes.map((r) => (
            <CarteRecette
              key={r.id}
              recette={r}
              favori={favoris.includes(r.id)}
              onFavori={() => basculerFavori(r.id)}
              onOuvrir={() => nav.ouvrirRecette(r.id)}
            />
          ))}
        </div>
      </section>

      <p className="text-center text-[12px] text-[var(--encre-douce)] mt-10 px-8 leading-relaxed">
        {RECETTES.length} recettes végétariennes · Inspiré du livre «&nbsp;Easy + Healthy Air Fryer&nbsp;» (Delish)
      </p>
    </div>
  )
}
