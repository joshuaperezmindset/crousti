import { RECETTES } from '../data/recettes'
import { LogoCrousti, IconeCoeur, IconePanier, IconeFlecheDroite, IconeCuisine } from '../components/icones'

export default function Profil({
  nbFavoris,
  nbEpicerie,
  allerFavoris,
  allerEpicerie,
  allerRecherche,
  refaireOnboarding,
}: {
  nbFavoris: number
  nbEpicerie: number
  allerFavoris: () => void
  allerEpicerie: () => void
  allerRecherche: () => void
  refaireOnboarding: () => void
}) {
  const lignes = [
    { label: 'Mes favoris', detail: `${nbFavoris} recette${nbFavoris > 1 ? 's' : ''}`, icone: IconeCoeur, action: allerFavoris },
    { label: 'Ma liste d’épicerie', detail: `${nbEpicerie} article${nbEpicerie > 1 ? 's' : ''}`, icone: IconePanier, action: allerEpicerie },
    { label: 'Explorer les recettes', detail: `${RECETTES.length} recettes végétariennes`, icone: IconeCuisine, action: allerRecherche },
  ]

  return (
    <div className="pb-28 px-5 pt-6" style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top))' }}>
      <div className="flex flex-col items-center text-center pt-4 pb-8">
        <LogoCrousti className="w-16 h-16 anim-pop" />
        <h1 className="font-display text-[28px] font-semibold text-[var(--encre)] mt-4">Crousti</h1>
        <p className="text-[14px] text-[var(--encre-douce)] mt-1">Ouvrir → choisir → cuisiner.</p>
      </div>

      <ul className="bg-[var(--carte)] border border-[var(--ligne)] rounded-[22px] divide-y divide-[var(--ligne)] overflow-hidden decalle">
        {lignes.map((l) => (
          <li key={l.label}>
            <button onClick={l.action} className="anim-fade-up w-full flex items-center gap-4 px-5 py-4 text-left active:bg-[var(--creme)]">
              <span className="w-10 h-10 rounded-full bg-[var(--terracotta-pale)] text-[var(--terracotta)] flex items-center justify-center">
                <l.icone className="w-5 h-5" />
              </span>
              <span className="flex-1">
                <span className="block font-semibold text-[15px] text-[var(--encre)]">{l.label}</span>
                <span className="block text-[13px] text-[var(--encre-douce)]">{l.detail}</span>
              </span>
              <IconeFlecheDroite className="w-4 h-4 text-[var(--encre-douce)]" />
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-6 bg-[var(--carte)] border border-[var(--ligne)] rounded-[22px] p-5">
        <h2 className="font-display text-[17px] font-semibold text-[var(--encre)]">À propos</h2>
        <p className="text-[13.5px] text-[var(--encre-douce)] leading-relaxed mt-2">
          Crousti rassemble {RECETTES.length} recettes Air Fryer végétariennes inspirées du livre
          «&nbsp;Easy&nbsp;+&nbsp;Healthy Air Fryer&nbsp;» de Delish, traduites en français et converties en unités métriques.
        </p>
        <p className="text-[13.5px] text-[var(--encre-douce)] leading-relaxed mt-2">
          Vos favoris et votre liste d’épicerie sont conservés dans ce navigateur uniquement&nbsp;: ils ne sont pas synchronisés entre appareils, et vider les données du navigateur les efface.
        </p>
        <button
          onClick={refaireOnboarding}
          className="mt-4 text-[13px] font-semibold text-[var(--terracotta)]"
        >
          Revoir la présentation
        </button>
      </div>

      <p className="text-center text-[11px] text-[var(--encre-douce)] mt-8">Crousti · Version 1.0</p>
    </div>
  )
}
