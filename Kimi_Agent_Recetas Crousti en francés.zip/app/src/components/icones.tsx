// Icônes SVG dessinées à la main pour Crousti — trait fin, style éditorial
interface Props { className?: string }

export const IconeMaison = ({ className = 'w-6 h-6' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M9.5 21v-6h5v6" />
  </svg>
)

export const IconeLoupe = ({ className = 'w-6 h-6' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" className={className}>
    <circle cx="11" cy="11" r="7" /><path d="m20 20-3.8-3.8" />
  </svg>
)

export const IconeCoeur = ({ className = 'w-6 h-6', plein = false }: Props & { plein?: boolean }) => (
  <svg viewBox="0 0 24 24" fill={plein ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 20.5C7 16.5 3 13.2 3 9.3 3 6.4 5.2 4.5 7.7 4.5c1.7 0 3.3.9 4.3 2.4 1-1.5 2.6-2.4 4.3-2.4 2.5 0 4.7 1.9 4.7 4.8 0 3.9-4 7.2-9 11.2Z" />
  </svg>
)

export const IconePanier = ({ className = 'w-6 h-6' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 8h14l-1.3 12.2a1.5 1.5 0 0 1-1.5 1.3H7.8a1.5 1.5 0 0 1-1.5-1.3L5 8Z" /><path d="M8.5 10.5V6.7a3.5 3.5 0 0 1 7 0v3.8" />
  </svg>
)

export const IconeProfil = ({ className = 'w-6 h-6' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" className={className}>
    <circle cx="12" cy="8" r="4" /><path d="M4.5 20.5c1.4-3.4 4.3-5 7.5-5s6.1 1.6 7.5 5" />
  </svg>
)

export const IconeHorloge = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={className}>
    <circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" />
  </svg>
)

export const IconeFlamme = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 3c1 3-1.5 4.5-1.5 7a3 3 0 0 0 6 .5C17.5 8 14 6.5 14 4c2.5 1.5 5.5 4.5 5.5 9a7.5 7.5 0 0 1-15 0C4.5 8.5 8 4.5 12 3Z" />
  </svg>
)

export const IconePortions = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={className}>
    <circle cx="9" cy="8" r="3" /><path d="M3.5 19c.8-2.8 2.9-4 5.5-4s4.7 1.2 5.5 4" /><circle cx="17" cy="9" r="2.4" /><path d="M16 15.2c2.2.2 3.8 1.4 4.5 3.8" />
  </svg>
)

export const IconeEclair = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12l1-8Z" />
  </svg>
)

export const IconeFeuille = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 19C5 9 11 4 20 4c0 10-5 15-13 15" /><path d="M5 19c3-5 7-8.5 11-10.5" />
  </svg>
)

export const IconePanierIngredients = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 9.5 8 4m12 5.5L16 4" /><path d="M3.5 9.5h17l-1.6 9.7a1.5 1.5 0 0 1-1.5 1.3H6.6a1.5 1.5 0 0 1-1.5-1.3L3.5 9.5Z" /><path d="M9 13.5v3m3-3v3m3-3v3" />
  </svg>
)

export const IconeFlecheGauche = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M15 5l-7 7 7 7" />
  </svg>
)

export const IconeFlecheDroite = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m9 5 7 7-7 7" />
  </svg>
)

export const IconePlus = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={className}>
    <path d="M12 5v14M5 12h14" />
  </svg>
)

export const IconeCroix = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={className}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
)

export const IconeMinuteur = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" className={className}>
    <circle cx="12" cy="13.5" r="7.5" /><path d="M12 9.5v4l2.5 1.5" /><path d="M10 2.5h4" /><path d="M12 2.5V6" />
  </svg>
)

export const IconeCaseCochee = ({ className = 'w-6 h-6' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
)

export const IconePoubelle = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 7h16" /><path d="M9.5 7V4.5h5V7" /><path d="M6.5 7l1 13.5h9l1-13.5" /><path d="M10 11v6m4-6v6" />
  </svg>
)

export const IconeEtoile = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" className={className}>
    <path d="m12 3.5 2.6 5.3 5.9.9-4.2 4.1 1 5.8-5.3-2.8-5.3 2.8 1-5.8-4.2-4.1 5.9-.9L12 3.5Z" />
  </svg>
)

export const IconeDe = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" className={className}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" /><circle cx="8.5" cy="8.5" r="1.3" fill="currentColor" stroke="none" /><circle cx="15.5" cy="8.5" r="1.3" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1.3" fill="currentColor" stroke="none" /><circle cx="8.5" cy="15.5" r="1.3" fill="currentColor" stroke="none" /><circle cx="15.5" cy="15.5" r="1.3" fill="currentColor" stroke="none" />
  </svg>
)

export const IconeCuisine = ({ className = 'w-5 h-5' }: Props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 11h16a8 8 0 0 1-16 0Z" /><path d="M8 11V7.5A2.5 2.5 0 0 0 5.5 5" /><path d="M12 11V4.5" /><path d="M16 11V7.5a2.5 2.5 0 0 1 2.5-2.5" />
  </svg>
)

export const IconeLecture = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M7 4.5v15l13-7.5-13-7.5Z" /></svg>
)

export const IconePause = ({ className = 'w-4 h-4' }: Props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><rect x="6" y="4" width="4" height="16" rx="1.5" /><rect x="14" y="4" width="4" height="16" rx="1.5" /></svg>
)

export const LogoCrousti = ({ className = 'w-8 h-8' }: Props) => (
  <svg viewBox="0 0 32 32" fill="none" className={className}>
    <rect width="32" height="32" rx="9" fill="#d5593f" />
    <path d="M8 20.5c0-6 3.5-10.5 8-10.5s8 4.5 8 10.5" stroke="#fcf8ef" strokeWidth="2.4" strokeLinecap="round" />
    <path d="M11 20.5h10" stroke="#dfa43d" strokeWidth="2.4" strokeLinecap="round" />
    <circle cx="16" cy="14.5" r="1.6" fill="#fcf8ef" />
  </svg>
)
