import { useEffect, useMemo, useState } from 'react'
import { RECETTES } from './data/recettes'
import { useFavoris, useEpicerie, useStockageLocal } from './lib/store'
import Onboarding from './screens/Onboarding'
import Accueil from './screens/Accueil'
import Recherche from './screens/Recherche'
import type { PresetRecherche } from './screens/Recherche'
import RecetteDetail from './screens/RecetteDetail'
import ModeCuisine from './screens/ModeCuisine'
import Favoris from './screens/Favoris'
import Epicerie from './screens/Epicerie'
import Profil from './screens/Profil'
import { BarreNavigation } from './components/communs'

type Onglet = 'accueil' | 'recherche' | 'favoris' | 'epicerie' | 'profil'

export default function App() {
  const [onboardingVu, setOnboardingVu] = useStockageLocal<boolean>('crousti:onboarding', false)
  const [onglet, setOnglet] = useState<Onglet>('accueil')
  const [preset, setPreset] = useState<PresetRecherche | null>(null)
  const [recetteOuverte, setRecetteOuverte] = useState<string | null>(null)
  const [cuisine, setCuisine] = useState(false)

  const { favoris, basculer } = useFavoris()
  const epicerie = useEpicerie()

  const recette = useMemo(() => RECETTES.find((r) => r.id === recetteOuverte) ?? null, [recetteOuverte])

  // Verrouille le défilement de l'arrière-plan en mode cuisine
  useEffect(() => {
    document.body.style.overflow = cuisine ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [cuisine])

  const ouvrirRecette = (id: string) => {
    setRecetteOuverte(id)
    window.scrollTo({ top: 0 })
  }
  const fermerRecette = () => setRecetteOuverte(null)

  const allerRecherche = (p?: PresetRecherche) => {
    setPreset(p ?? null)
    setRecetteOuverte(null)
    setOnglet('recherche')
    window.scrollTo({ top: 0 })
  }

  const changerOnglet = (o: string) => {
    setOnglet(o as Onglet)
    setRecetteOuverte(null)
    if (o !== 'recherche') setPreset(null)
    window.scrollTo({ top: 0 })
  }

  if (!onboardingVu) {
    return <Onboarding onTerminer={() => setOnboardingVu(true)} />
  }

  return (
    <div className="min-h-full max-w-md mx-auto relative">
      {/* Vue recette (par-dessus l'onglet courant) */}
      {recette && (
        <div className="fixed inset-0 z-40 overflow-y-auto">
          <div className="max-w-md mx-auto min-h-full relative">
            <RecetteDetail
              recette={recette}
              favori={favoris.includes(recette.id)}
              onFavori={() => basculer(recette.id)}
              onRetour={fermerRecette}
              onAjouterEpicerie={() =>
                epicerie.ajouterRecette(recette.id, recette.titre, recette.ingredients)
              }
              onModeCuisine={() => setCuisine(true)}
            />
          </div>
        </div>
      )}

      {/* Onglets */}
      <div className={recette ? 'hidden' : ''}>
        {onglet === 'accueil' && (
          <Accueil
            favoris={favoris}
            basculerFavori={basculer}
            nav={{
              ouvrirRecette,
              allerRecherche,
              allerFavoris: () => changerOnglet('favoris'),
            }}
          />
        )}
        {onglet === 'recherche' && (
          <Recherche
            key={JSON.stringify(preset)}
            preset={preset}
            favoris={favoris}
            basculerFavori={basculer}
            ouvrirRecette={ouvrirRecette}
          />
        )}
        {onglet === 'favoris' && (
          <Favoris
            favoris={favoris}
            basculerFavori={basculer}
            ouvrirRecette={ouvrirRecette}
            allerRecherche={() => changerOnglet('recherche')}
          />
        )}
        {onglet === 'epicerie' && (
          <Epicerie
            articles={epicerie.articles}
            basculer={epicerie.basculer}
            supprimer={epicerie.supprimer}
            ajouterManuel={epicerie.ajouterManuel}
            viderCoches={epicerie.viderCoches}
            allerRecherche={() => changerOnglet('recherche')}
          />
        )}
        {onglet === 'profil' && (
          <Profil
            nbFavoris={favoris.length}
            nbEpicerie={epicerie.articles.length}
            allerFavoris={() => changerOnglet('favoris')}
            allerEpicerie={() => changerOnglet('epicerie')}
            allerRecherche={() => changerOnglet('recherche')}
            refaireOnboarding={() => setOnboardingVu(false)}
          />
        )}
        <BarreNavigation
          onglet={onglet}
          onChange={changerOnglet}
          nbEpicerie={epicerie.articles.filter((a) => !a.coche).length}
        />
      </div>

      {/* Mode cuisine (plein écran) */}
      {cuisine && recette && (
        <ModeCuisine recette={recette} onQuitter={() => setCuisine(false)} />
      )}
    </div>
  )
}
