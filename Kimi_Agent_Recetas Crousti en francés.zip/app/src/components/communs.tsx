import { CATEGORIES } from '../data/recettes'
import type { Recette } from '../data/recettes'
import { IconeHorloge, IconeCoeur, IconePanier, IconeLoupe, IconeCuisine, LogoCrousti } from './icones'

export function BadgeDifficulte({ difficulte }: { difficulte: string }) {
  const styles: Record<string, string> = {
    Facile: 'bg-[var(--vert-pale)] text-[#0d7a57]',
    'Intermédiaire': 'bg-[var(--moutarde-pale)] text-[#9a6b12]',
    'Avancé': 'bg-[var(--terracotta-pale)] text-[var(--terracotta-fonce)]',
  }
  return (
    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${styles[difficulte] ?? styles.Facile}`}>
      {difficulte}
    </span>
  )
}

export function CarteRecette({
  recette,
  favori,
  onFavori,
  onOuvrir,
  grande = false,
}: {
  recette: Recette
  favori: boolean
  onFavori: () => void
  onOuvrir: () => void
  grande?: boolean
}) {
  const total = recette.tempsPrep + recette.tempsCuisson
  return (
    <article
      onClick={onOuvrir}
      className={`anim-fade-up bg-[var(--carte)] rounded-[22px] overflow-hidden cursor-pointer active:scale-[0.98] transition-transform border border-[var(--ligne)] ${
        grande ? 'w-[270px] shrink-0' : 'w-full'
      }`}
      style={{ boxShadow: '0 2px 14px rgba(46,38,32,0.06)' }}
    >
      <div className={`relative overflow-hidden ${grande ? 'h-40' : 'h-44'}`}>
        <img
          src={recette.image}
          alt={recette.titre}
          loading="lazy"
          className="w-full h-full object-cover anim-scale-in"
        />
        <button
          aria-label={favori ? 'Retirer des favoris' : 'Ajouter aux favoris'}
          onClick={(e) => { e.stopPropagation(); onFavori() }}
          className={`absolute top-3 right-3 w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${
            favori ? 'bg-[var(--terracotta)] text-white' : 'bg-white/85 text-[var(--encre)]'
          }`}
        >
          <IconeCoeur plein={favori} className="w-4.5 h-4.5 w-[18px] h-[18px]" />
        </button>
      </div>
      <div className="p-4">
        <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[var(--terracotta)] mb-1">
          {CATEGORIES[recette.categorie]}
        </p>
        <h3 className="font-display font-semibold text-[17px] leading-snug text-[var(--encre)] line-clamp-2">
          {recette.titre}
        </h3>
        <div className="flex items-center gap-2 mt-2.5">
          <span className="flex items-center gap-1 text-[13px] text-[var(--encre-douce)] whitespace-nowrap shrink-0">
            <IconeHorloge className="w-3.5 h-3.5 shrink-0" /> {total}{'\u00a0'}min
          </span>
          <BadgeDifficulte difficulte={recette.difficulte} />
        </div>
      </div>
    </article>
  )
}

export function EtatVide({
  icone,
  titre,
  texte,
  action,
  onAction,
}: {
  icone: React.ReactNode
  titre: string
  texte: string
  action?: string
  onAction?: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center px-8 py-16 anim-pop">
      <div className="w-16 h-16 rounded-full bg-[var(--creme-fonce)] flex items-center justify-center text-[var(--terracotta)] mb-5">
        {icone}
      </div>
      <h3 className="font-display text-xl font-semibold text-[var(--encre)]">{titre}</h3>
      <p className="text-[14px] text-[var(--encre-douce)] mt-2 leading-relaxed max-w-[260px]">{texte}</p>
      {action && (
        <button
          onClick={onAction}
          className="mt-6 px-6 py-3 rounded-full bg-[var(--terracotta)] text-white font-semibold text-[15px] active:scale-95 transition-transform"
        >
          {action}
        </button>
      )}
    </div>
  )
}

export function BarreNavigation({
  onglet,
  onChange,
  nbEpicerie,
}: {
  onglet: string
  onChange: (o: string) => void
  nbEpicerie: number
}) {
  const items = [
    { id: 'accueil', label: 'Accueil', icone: IconeCuisine },
    { id: 'recherche', label: 'Recherche', icone: IconeLoupe },
    { id: 'favoris', label: 'Favoris', icone: IconeCoeur },
    { id: 'epicerie', label: 'Épicerie', icone: IconePanier },
    { id: 'profil', label: 'Profil', icone: LogoCrousti },
  ]
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-lg border-t border-[var(--ligne)]"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="max-w-md mx-auto flex items-stretch justify-between px-2">
        {items.map((item) => {
          const actif = onglet === item.id
          const Icone = item.icone
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={`relative flex flex-col items-center gap-1 py-2.5 px-3 min-w-[60px] transition-colors ${
                actif ? 'text-[var(--terracotta)]' : 'text-[var(--encre-douce)]'
              }`}
            >
              <Icone className="w-6 h-6" />
              <span className={`text-[10px] ${actif ? 'font-bold' : 'font-medium'}`}>{item.label}</span>
              {item.id === 'epicerie' && nbEpicerie > 0 && (
                <span className="absolute top-1 right-2 min-w-[18px] h-[18px] px-1 rounded-full bg-[var(--moutarde)] text-[var(--encre)] text-[10px] font-bold flex items-center justify-center">
                  {nbEpicerie}
                </span>
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

export function Chip({
  label,
  actif,
  onClick,
}: {
  label: string
  actif: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full text-[14px] font-medium whitespace-nowrap transition-all active:scale-95 border ${
        actif
          ? 'bg-[var(--encre)] text-[var(--creme)] border-[var(--encre)]'
          : 'bg-[var(--carte)] text-[var(--encre)] border-[var(--ligne)]'
      }`}
    >
      {label}
    </button>
  )
}
