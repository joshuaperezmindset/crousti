import { useCallback, useEffect, useState } from 'react'

// Persistance locale (navigateur) pour Crousti

function lire<T>(cle: string, defaut: T): T {
  try {
    const v = localStorage.getItem(cle)
    return v ? (JSON.parse(v) as T) : defaut
  } catch {
    return defaut
  }
}

function ecrire<T>(cle: string, valeur: T) {
  try {
    localStorage.setItem(cle, JSON.stringify(valeur))
  } catch {
    /* stockage indisponible */
  }
}

export function useStockageLocal<T>(cle: string, defaut: T) {
  const [valeur, setValeur] = useState<T>(() => lire(cle, defaut))
  useEffect(() => {
    ecrire(cle, valeur)
  }, [cle, valeur])
  return [valeur, setValeur] as const
}

export interface ArticleEpicerie {
  id: string
  nom: string
  quantite: string
  groupe: string
  recetteTitre?: string
  coche: boolean
}

export function useFavoris() {
  const [favoris, setFavoris] = useStockageLocal<string[]>('crousti:favoris', [])
  const basculer = useCallback(
    (id: string) =>
      setFavoris((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id])),
    [setFavoris]
  )
  return { favoris, basculer }
}

export function useEpicerie() {
  const [articles, setArticles] = useStockageLocal<ArticleEpicerie[]>('crousti:epicerie', [])

  const ajouterRecette = useCallback(
    (recetteId: string, recetteTitre: string, ingredients: { nom: string; quantite: string; groupe: string }[]) => {
      setArticles((arts) => {
        const existants = new Set(arts.filter((a) => a.recetteTitre === recetteTitre).map((a) => a.nom))
        const nouveaux = ingredients
          .filter((i) => !existants.has(i.nom))
          .map((i, idx) => ({
            id: `${recetteId}-${idx}-${Date.now()}`,
            nom: i.nom,
            quantite: i.quantite,
            groupe: i.groupe,
            recetteTitre,
            coche: false,
          }))
        return [...arts, ...nouveaux]
      })
    },
    [setArticles]
  )

  const ajouterManuel = useCallback(
    (nom: string) => {
      if (!nom.trim()) return
      setArticles((arts) => [
        ...arts,
        { id: `manuel-${Date.now()}`, nom: nom.trim(), quantite: '', groupe: 'Autres', coche: false },
      ])
    },
    [setArticles]
  )

  const basculer = useCallback(
    (id: string) => setArticles((arts) => arts.map((a) => (a.id === id ? { ...a, coche: !a.coche } : a))),
    [setArticles]
  )

  const supprimer = useCallback(
    (id: string) => setArticles((arts) => arts.filter((a) => a.id !== id)),
    [setArticles]
  )

  const viderCoches = useCallback(
    () => setArticles((arts) => arts.filter((a) => !a.coche)),
    [setArticles]
  )

  return { articles, ajouterRecette, ajouterManuel, basculer, supprimer, viderCoches }
}
